from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    discription="its a wine q package",
    author="akshay",
    packages=find_packages(),
    licence="MIT",

)
